package com.niit.Shopcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class CategoryTest {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		
		Category category = (Category) context.getBean("category");
		category.setCat_des("des");
		category.setCat_id("CG1");
		category.setCat_name("DELL");
		
		categoryDAO.saveOrUpdate(category);
	}
}
